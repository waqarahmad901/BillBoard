﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BillBoardsManagement.Common
{
    public enum EnumUserRole
    {
        SuperAdmin = 1001,
        User = 1002
    } 
    
}