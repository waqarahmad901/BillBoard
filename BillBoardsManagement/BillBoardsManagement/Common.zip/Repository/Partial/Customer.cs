﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BillBoardsManagement.Repository
{
    public partial class Customer
    {
        public string NewType { get; set; } 
        public string NewBrand { get; set; }

    }
}